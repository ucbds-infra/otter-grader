test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> nine\n9', 'failure_message': None, 'hidden': False, 'locked': False, 'points': None, 'success_message': None},
                                   {'code': '>>> square(16)\n256', 'failure_message': None, 'hidden': False, 'locked': False, 'points': None, 'success_message': None},
                                   {'code': '>>> square(1)\n1', 'failure_message': None, 'hidden': True, 'locked': False, 'points': None, 'success_message': None}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
