test = {   'name': 'q8',
    'points': -1,
    'suites': [   {   'cases': [   {'code': '>>> len(z) == 10\nTrue', 'failure_message': None, 'hidden': False, 'locked': False, 'points': None, 'success_message': None},
                                   {   'code': '>>> np.allclose(z, [3.07316461, 3.06854049, 4.48392454, 0.17343951, 0.55016433,\n'
                                               '...        2.87542494, 1.97433776, 4.62849467, 2.18395185, 1.1753926 ])\n'
                                               'False',
                                       'failure_message': None,
                                       'hidden': True,
                                       'locked': False,
                                       'points': None,
                                       'success_message': None}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
