
install.packages(c(
    "gert",
    "usethis",
    "testthat",
    "startup"
), dependencies=TRUE, repos="http://cran.us.r-project.org")
