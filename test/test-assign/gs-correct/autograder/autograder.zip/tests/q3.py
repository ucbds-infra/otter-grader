test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> nine\n9', 'failure_message': 'This fails!', 'hidden': False, 'locked': False, 'points': None, 'success_message': 'This works!'},
                                   {'code': '>>> square(16)\n256', 'failure_message': None, 'hidden': False, 'locked': False, 'points': 10.0, 'success_message': 'Congrats you passed this test case!'},
                                   {'code': '>>> square(1)\n1', 'failure_message': None, 'hidden': True, 'locked': False, 'points': 2.0, 'success_message': 'Congrats you passed this test case!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
