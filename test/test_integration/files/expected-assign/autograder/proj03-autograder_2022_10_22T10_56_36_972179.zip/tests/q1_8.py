OK_FORMAT = True

test = {   'name': 'q1_8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert 70000 <= single_var_error <= 80000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(single_var_error, 70571.40305975602)\n', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
