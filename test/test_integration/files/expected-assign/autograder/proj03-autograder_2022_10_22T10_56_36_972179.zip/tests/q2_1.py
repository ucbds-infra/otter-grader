OK_FORMAT = True

test = {   'name': 'q2_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> q2_1 in ["a", "b", "c", "d"]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> q2_1 == "d"\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
