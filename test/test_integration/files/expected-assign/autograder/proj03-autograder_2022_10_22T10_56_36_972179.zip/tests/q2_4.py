OK_FORMAT = True

test = {   'name': 'q2_4',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> assert len(new_features) == 6\n>>> assert new_X.shape[1] == 6\n>>> assert len(new_Y_hat) == defaults.shape[0]\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
