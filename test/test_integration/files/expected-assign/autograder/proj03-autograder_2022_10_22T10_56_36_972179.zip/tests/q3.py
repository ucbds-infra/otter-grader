OK_FORMAT = True

test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [{'code': '>>> assert len(my_labels) <= 10\n>>> assert "bill_sep05" not in my_labels\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
