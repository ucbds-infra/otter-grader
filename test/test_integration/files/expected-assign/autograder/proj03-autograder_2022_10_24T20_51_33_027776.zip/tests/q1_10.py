OK_FORMAT = True

test = {   'name': 'q1_10',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert -4000 <= default_beta_1 <= -3000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert 51000 <= default_beta_0 <= 52000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert np.isclose(default_beta_1, -3485.0649761630766)\n', 'hidden': True, 'locked': False, 'points': 1},
                                   {'code': '>>> assert np.isclose(default_beta_0, 51994.22727272727)\n', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
