OK_FORMAT = True

test = {   'name': 'q0_2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert "education" not in defaults.columns\n>>> assert "marital_status" not in defaults.columns\n>>> assert "sex_male" in defaults.columns\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
