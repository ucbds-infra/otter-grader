OK_FORMAT = True

test = {   'name': 'q0_1',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> assert len(q0_1) in [3, 4]\n>>> assert "sex" in q0_1\n>>> assert "education" in q0_1\n>>> assert "marital_status" in q0_1\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
