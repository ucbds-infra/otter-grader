OK_FORMAT = True

test = {   'name': 'q2_5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert 22000 <= new_rmse <= 23000\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(new_rmse, 22495.963258409643)\nTrue', 'hidden': True, 'locked': False, 'points': 1}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
