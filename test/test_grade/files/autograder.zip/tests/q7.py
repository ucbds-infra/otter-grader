OK_FORMAT = True

test = {
	"name": "q7",
	"points": 1,
	"hidden": True,
	"suites": [ 
		{
			"cases": [ 
				{
					"code": r"""
					>>> import tqdm  # check that tqdm is installed
					""",
					"hidden": False,
					"locked": False,
				},  
			],
			"scored": False,
			"setup": "",
			"teardown": "",
			"type": "doctest"
		}
	]
}