OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> nine\n9', 'hidden': False, 'locked': False},
                                   {'code': '>>> square(16)\n256', 'hidden': False, 'locked': False},
                                   {'code': '>>> square(1)\n1', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
