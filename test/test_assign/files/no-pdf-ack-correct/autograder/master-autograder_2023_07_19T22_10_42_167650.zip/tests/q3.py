OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> nine\n9', 'failure_message': 'This fails!', 'hidden': False, 'locked': False, 'success_message': 'This works!'},
                                   {'code': '>>> square(16)\n256', 'hidden': False, 'locked': False, 'points': 10, 'success_message': 'Congrats you passed this test case!'},
                                   {'code': '>>> square(1)\n1', 'hidden': True, 'locked': False, 'points': 2, 'success_message': 'Congrats you passed this test case!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
