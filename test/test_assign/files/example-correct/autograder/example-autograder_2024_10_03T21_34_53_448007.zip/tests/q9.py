OK_FORMAT = True

test = {   'name': 'q9',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> add(3, 4) == 7\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> s == 3\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
