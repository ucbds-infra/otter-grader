test = list(
  name = "q3",
  cases = list(
    ottr::TestCase$new(
      hidden = FALSE,
      name = NA,
      points = 0.6666666666666666,
      code = {
        testthat::expect_equal(nine, 9)
      }
    ),
    ottr::TestCase$new(
      hidden = FALSE,
      name = NA,
      points = 0.6666666666666666,
      code = {
        testthat::expect_equal(square(16), 256)
      }
    ),
    ottr::TestCase$new(
      hidden = TRUE,
      name = NA,
      points = 0.6666666666666666,
      code = {
        testthat::expect_equal(square(1), 1)
      }
    )
  )
)